package com.g7.ridera.adapter;

import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.g7.ridera.fragments.AlertNotificationFragment;
import com.g7.ridera.fragments.NotificationFragment;
import com.g7.ridera.fragments.UpdateNotificationFragment;

public class NotificationPagerAdapter extends FragmentStatePagerAdapter {

    private Context context;
    private int tabCount;

    public NotificationPagerAdapter(Context context, FragmentManager fragmentManager, int tabCount) {
        super(fragmentManager);
        this.context = context;
        this.tabCount = tabCount;
    }

    @Override
    public int getCount() {
        return tabCount;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return "All";
            case 1:
                return "Alerts";
            case 2:
                return "Updates";
            default:
                return null;
        }
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new NotificationFragment();
            case 1:
                return new AlertNotificationFragment();
            case 2:
                return new UpdateNotificationFragment();
            default:
                return null;
        }
    }
}


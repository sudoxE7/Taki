package com.g7.ridera.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.g7.ridera.R;

import java.util.ArrayList;
import java.util.HashMap;

public class DrawerItemAdapter extends RecyclerView.Adapter<DrawerItemAdapter.ViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(int position, HashMap<String, Object> item);
    }

    private final Context context;
    private final ArrayList<HashMap<String, Object>> data;
    private final int layoutRes;
    private OnItemClickListener listener;

    public DrawerItemAdapter(Context context, ArrayList<HashMap<String, Object>> data, int layoutRes) {
        this.context = context;
        this.data = data;
        this.layoutRes = layoutRes;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(layoutRes, parent, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        HashMap<String, Object> item = data.get(position);

        holder.tvTitle.setText((String) item.get("title"));

        holder.ivIcon.setImageResource(
                context.getResources().getIdentifier((String) item.get("icon"), "drawable", context.getPackageName())
        );

        holder.ivArrow.setImageResource(
                context.getResources().getIdentifier((String) item.get("arrow"), "drawable", context.getPackageName())
        );

        // CLICK EVENT
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onItemClick(position, item);
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final ImageView ivIcon, ivArrow;
        final TextView tvTitle;

        ViewHolder(View itemView) {
            super(itemView);
            ivIcon = itemView.findViewById(R.id.ivIcon);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            ivArrow = itemView.findViewById(R.id.ivArrow);
        }
    }
}

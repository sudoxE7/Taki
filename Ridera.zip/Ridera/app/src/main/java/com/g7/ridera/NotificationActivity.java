package com.g7.ridera;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.g7.ridera.adapter.NotificationPagerAdapter;
import com.g7.ridera.adapter.ViewPagerNoSwipe;
import com.google.android.material.tabs.TabLayout;

public class NotificationActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        TabLayout tabLayout = findViewById(R.id.tabLayout);
        ViewPager viewPager = findViewById(R.id.viewPager);

        tabLayout.setupWithViewPager(viewPager);
        viewPager.setAdapter(new NotificationPagerAdapter(getApplicationContext(), getSupportFragmentManager(), 3));

        // Setup PageTransformer
        viewPager.setPageTransformer(false, new ViewPagerNoSwipe.PageTransformer() {
            @Override
            public void transformPage(@NonNull View page, float position) {
                page.setAlpha(0f);
                page.setVisibility(View.VISIBLE);

                // Start Animation for a short period of time
                page.animate().alpha(1f)
                        .setDuration(page.getResources().getInteger(android.R.integer.config_longAnimTime)
                                - page.getResources().getInteger(android.R.integer.config_shortAnimTime));
            }
        });

        // Setup TabSelectedListener
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                // No action needed when a tab is reselected
            }
        });

        // click event
        findViewById(R.id.ibBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(NotificationActivity.this, HomeActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP));
                overridePendingTransition(R.anim.animate_slide_in_left, R.anim.animate_slide_out_right);
            }
        });

        findViewById(R.id.ibMarkAsRead).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(NotificationActivity.this, "Mark as Read", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(NotificationActivity.this, HomeActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP));
        overridePendingTransition(R.anim.animate_slide_in_left, R.anim.animate_slide_out_right);
    }
}

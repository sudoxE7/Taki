package com.g7.ridera;

import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.g7.ridera.adapter.ContactItemAdapter;
import com.g7.ridera.adapter.DrawerItemAdapter;

import java.util.ArrayList;
import java.util.HashMap;

public class ContactActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        // contact list
        ArrayList<HashMap<String, Object>> contactList = new ArrayList<>();

        for (int i = 0; i < 1; i++) {
            HashMap<String, Object> item = new HashMap<>();
            item.put("name", "Name");
            item.put("relationship", "Relationship");
            item.put("mobile", "+63 9XX XXX XXXX");
            contactList.add(item);
        }

        initRecycler(R.id.recyclerView, contactList, true);

        // click event
        findViewById(R.id.ibBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ContactActivity.this, HomeActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP));
                overridePendingTransition(R.anim.animate_slide_in_left, R.anim.animate_slide_out_right);
            }
        });

        findViewById(R.id.ibAddContact).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ContactActivity.this, "Add Emergency Contact", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(ContactActivity.this, HomeActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP));
        overridePendingTransition(R.anim.animate_slide_in_left, R.anim.animate_slide_out_right);
    }

    private void initRecycler(int recyclerId, ArrayList<HashMap<String, Object>> list, boolean addDivider) {
        RecyclerView rv = findViewById(recyclerId);
        rv.setLayoutManager(new LinearLayoutManager(this));

        ContactItemAdapter adapter = new ContactItemAdapter(this, list, R.layout.emergency_contact_item);

        adapter.setOnItemClickListener((position, item) -> {
            String title = (String) item.get("name");
            Toast.makeText(this, "Clicked: " + title, Toast.LENGTH_SHORT).show();
        });

        rv.setAdapter(adapter);

        if (addDivider) {
            rv.addItemDecoration(new RecyclerView.ItemDecoration() {

                final int margin = (int) (0 * rv.getResources().getDisplayMetrics().density); // 24dp to px
                final Drawable divider = new ColorDrawable(Color.parseColor("#ffd8d8d8"));

                @Override
                public void onDrawOver(Canvas canvas, RecyclerView parent, RecyclerView.State state) {
                    int left = parent.getPaddingLeft() + margin;
                    int right = parent.getWidth() - parent.getPaddingRight() - margin;

                    int childCount = parent.getChildCount();
                    for (int i = 0; i < childCount; i++) {
                        View child = parent.getChildAt(i);
                        RecyclerView.LayoutParams params =
                                (RecyclerView.LayoutParams) child.getLayoutParams();

                        int top = child.getBottom() + params.bottomMargin;
                        int bottom = top + 2; // divider thickness

                        divider.setBounds(left, top, right, bottom);
                        divider.draw(canvas);
                    }
                }
            });
        }
    }
}

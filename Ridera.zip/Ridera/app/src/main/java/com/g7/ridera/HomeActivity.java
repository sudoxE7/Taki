package com.g7.ridera;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.g7.ridera.adapter.DrawerItemAdapter;
import com.g7.ridera.effects.RadiateLayout;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.HashMap;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Drawer
        DrawerLayout drawer = findViewById(R.id.drawerLayout);

        // Load JSON
        ArrayList<HashMap<String, Object>> dataList = new Gson().fromJson(
                RideraUtils.getJsonFromAssets(this, "navigation_drawer_item.json"),
                new TypeToken<ArrayList<HashMap<String, Object>>>() {
                }.getType()
        );

        // Split list (top / bottom)
        ArrayList<HashMap<String, Object>> topList = new ArrayList<>(dataList.subList(0, 2));
        ArrayList<HashMap<String, Object>> bottomList = new ArrayList<>(dataList.subList(2, dataList.size()));

        initRecycler(R.id.recyclerView, topList, true);

        initRecycler(R.id.recyclerView2, bottomList, false);

        findViewById(R.id.ibDrawer).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawer.openDrawer(Gravity.START);
            }
        });

        // Notification
        findViewById(R.id.ibNotification).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, NotificationActivity.class));
                overridePendingTransition(R.anim.animate_slide_left_enter, R.anim.animate_slide_left_exit);
            }
        });

        // Power Button
        RadiateLayout ripple = findViewById(R.id.ripple);
        ripple.startAnimation();

        findViewById(R.id.btnPower).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(HomeActivity.this, "Power Button", Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.btnRegisteredContact).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, ContactActivity.class));
                overridePendingTransition(R.anim.animate_slide_left_enter, R.anim.animate_slide_left_exit);
            }
        });
    }

    private void initRecycler(int recyclerId, ArrayList<HashMap<String, Object>> list, boolean addDivider) {
        RecyclerView rv = findViewById(recyclerId);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setOverScrollMode(View.OVER_SCROLL_NEVER);

        DrawerItemAdapter adapter = new DrawerItemAdapter(this, list, R.layout.navigation_drawer_item);

        adapter.setOnItemClickListener((position, item) -> {
            String title = (String) item.get("title");
            Toast.makeText(this, "Clicked: " + title, Toast.LENGTH_SHORT).show();

            switch (title) {
                case "Account":
                    // open Account Activity
                    break;
                case "Settings":
                    // open Settings Activity
                    break;
                case "Share":
                    // share something
                    break;
                case "About":
                    // show About dialog
                    break;
            }
        });

        rv.setAdapter(adapter);

        if (addDivider) {
            DividerItemDecoration divider = new DividerItemDecoration(this, LinearLayoutManager.VERTICAL);
            divider.setDrawable(new ColorDrawable(Color.parseColor("#D8D8D8")));
            rv.addItemDecoration(divider);
        }
    }
}

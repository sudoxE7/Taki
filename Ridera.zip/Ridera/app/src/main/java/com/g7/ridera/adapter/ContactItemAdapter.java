package com.g7.ridera.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.g7.ridera.R;

import java.util.ArrayList;
import java.util.HashMap;

public class ContactItemAdapter extends RecyclerView.Adapter<ContactItemAdapter.ViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(int position, HashMap<String, Object> item);
    }

    private final Context context;
    private final ArrayList<HashMap<String, Object>> data;
    private final int layoutRes;
    private OnItemClickListener listener;

    public ContactItemAdapter(Context context, ArrayList<HashMap<String, Object>> data, int layoutRes) {
        this.context = context;
        this.data = data;
        this.layoutRes = layoutRes;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(layoutRes, parent, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        HashMap<String, Object> item = data.get(position);

        holder.tvName.setText((String) item.get("name"));

        holder.tvRelationship.setText((String) item.get("relationship"));

        holder.tvMobile.setText((String) item.get("mobile"));

        // CLICK EVENT
        holder.btnDelete.setOnClickListener(v -> {
            if (listener != null) listener.onItemClick(position, item);
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView tvName, tvRelationship, tvMobile;
        final LinearLayout btnDelete;

        ViewHolder(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvRelationship = itemView.findViewById(R.id.tvRelationship);
            tvMobile = itemView.findViewById(R.id.tvMobile);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}

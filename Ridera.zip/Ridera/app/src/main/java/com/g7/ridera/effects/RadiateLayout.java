package com.g7.ridera.effects;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.RelativeLayout;

import java.util.ArrayList;

public class RadiateLayout extends RelativeLayout {

    private static final int RIPPLE_COLOR = 0xffeb0a1e;     // default Ridera color
    private static final int RIPPLE_COUNT = 4;
    private static final int RIPPLE_DURATION = 3000;
    private static final float RIPPLE_SCALE = 1.5f;
    private static final float RIPPLE_STROKE = 4f;
    private static final float RIPPLE_RADIUS = 140f;

    private Paint paint;
    private boolean animationRunning = false;
    private AnimatorSet animatorSet;
    private ArrayList<RippleView> rippleViewList = new ArrayList<>();

    public RadiateLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public RadiateLayout(Context context) {
        super(context);
        init();
    }

    private void init() {

        paint = new Paint();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(RIPPLE_COLOR);

        animatorSet = new AnimatorSet();
        animatorSet.setInterpolator(new AccelerateDecelerateInterpolator());
        ArrayList<Animator> animatorList = new ArrayList<>();

        int delay = RIPPLE_DURATION / RIPPLE_COUNT;

        LayoutParams params = new LayoutParams(
                (int) (RIPPLE_RADIUS * 2),
                (int) (RIPPLE_RADIUS * 2)
        );
        params.addRule(CENTER_IN_PARENT, TRUE);

        // Create ripple circles
        for (int i = 0; i < RIPPLE_COUNT; i++) {
            RippleView ripple = new RippleView(getContext());
            addView(ripple, params);
            rippleViewList.add(ripple);

            animatorList.add(createScaleX(ripple, i, delay));
            animatorList.add(createScaleY(ripple, i, delay));
            animatorList.add(createAlpha(ripple, i, delay));
        }

        animatorSet.playTogether(animatorList);
    }

    private ObjectAnimator createScaleX(View v, int index, int delay) {
        ObjectAnimator anim = ObjectAnimator.ofFloat(v, "scaleX", 1f, RIPPLE_SCALE);
        anim.setDuration(RIPPLE_DURATION);
        anim.setRepeatCount(ObjectAnimator.INFINITE);
        anim.setStartDelay(index * delay);
        return anim;
    }

    private ObjectAnimator createScaleY(View v, int index, int delay) {
        ObjectAnimator anim = ObjectAnimator.ofFloat(v, "scaleY", 1f, RIPPLE_SCALE);
        anim.setDuration(RIPPLE_DURATION);
        anim.setRepeatCount(ObjectAnimator.INFINITE);
        anim.setStartDelay(index * delay);
        return anim;
    }

    private ObjectAnimator createAlpha(View v, int index, int delay) {
        ObjectAnimator anim = ObjectAnimator.ofFloat(v, "alpha", 1f, 0f);
        anim.setDuration(RIPPLE_DURATION);
        anim.setRepeatCount(ObjectAnimator.INFINITE);
        anim.setStartDelay(index * delay);
        return anim;
    }

    private class RippleView extends View {
        public RippleView(Context context) {
            super(context);
            setVisibility(INVISIBLE);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int radius = Math.min(getWidth(), getHeight()) / 2;
            canvas.drawCircle(radius, radius, radius - RIPPLE_STROKE, paint);
        }
    }

    public void startAnimation() {
        if (!animationRunning) {
            for (RippleView rv : rippleViewList) rv.setVisibility(VISIBLE);
            animatorSet.start();
            animationRunning = true;
        }
    }

    public void stopAnimation() {
        if (animationRunning) {
            animatorSet.end();
            for (RippleView rv : rippleViewList) rv.setVisibility(INVISIBLE);
            animationRunning = false;
        }
    }

    public boolean isRunning() {
        return animationRunning;
    }

    public void setRippleColor(int color) {
        paint.setColor(color);

        for (RippleView rv : rippleViewList) {
            rv.invalidate();
        }
    }
}

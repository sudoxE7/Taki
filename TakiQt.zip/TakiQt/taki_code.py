import os
os.environ["QT_ENABLE_HIGHDPI_SCALING"] = "0"

from PySide6.QtWidgets import QApplication, QStackedWidget, QLabel
from PySide6.QtUiTools import QUiLoader
from PySide6.QtCore import QTimer
import sys

if __name__ == "__main__":
    app = QApplication(sys.argv)

    loader = QUiLoader()
    window = loader.load("taki.ui")
    window.setFixedSize(390, 844)

    screen = app.primaryScreen().geometry()
    x = (screen.width() - 390) // 2
    y = (screen.height() - 844) // 2
    window.move(x, y)

    window.show()

    stacked_widget = window.findChild(QStackedWidget, "stackedWidget")

    if stacked_widget is None:
        print("ERROR: QStackedWidget with objectName 'stackedWidget' not found in UI.")
    else:
        def switch_to_page2():
            stacked_widget.setCurrentIndex(1)

        QTimer.singleShot(3000, switch_to_page2)

    sys.exit(app.exec())

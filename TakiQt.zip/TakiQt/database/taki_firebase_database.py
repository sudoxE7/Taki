import pyrebase
from datetime import datetime

database = pyrebase.initialize_app({
    "apiKey": "AIzaSyBP-2VNHqs4iVY7ZyfxooMiygaLi5bVvpA",
    "authDomain": "taki-207f0.firebaseapp.com",
    "databaseURL": "https://taki-207f0-default-rtdb.firebaseio.com/",
    "storageBucket": "taki-207f0.appspot.com"
}).database()

def formatUsername(username):
    return username.replace(".", "").replace("@", "").replace("#", "")

def chatId(sender, receiver):
    return "-to-".join(sorted(map(formatUsername, [sender, receiver])))

def getMessages(sender, receiver):
    snapshot = database.child("Taki").child("chats").child(chatId(sender, receiver)).get()
    return sorted([s.val() for s in snapshot.each() or []], key=lambda m: m["timestamp"])

def sendMessage(sender, receiver, text):
    timestamp = datetime.now().isoformat(timespec="seconds")
    database.child("Taki").child("chats").child(chatId(sender, receiver)).child(timestamp).set({
        "sender": sender,
        "message": text, 
        "timestamp": timestamp,
        "read": False
    })

def markAsRead(currentUser, otherUser):
    chatKey = chatId(currentUser, otherUser)
    chatRef = database.child("Taki").child("chats").child(chatKey)
    messagesSnapshot = chatRef.get()

    if messagesSnapshot.each() is None:
        return

    for message in messagesSnapshot.each():
        messageData = message.val()
        messageKey = message.key()

        if messageData.get("sender") == otherUser and not messageData.get("read", False):
            database.child("Taki").child("chats").child(chatKey).child(messageKey).update({"read": True})
            
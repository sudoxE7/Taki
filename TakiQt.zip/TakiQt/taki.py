import warnings
warnings.filterwarnings("ignore", category=UserWarning)

import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))

import sys, shutil, sqlite3
from datetime import datetime, timedelta

from PyQt5 import QtWidgets, uic, QtGui, QtCore
from PyQt5.QtWidgets import QApplication, QMainWindow, QListWidgetItem, QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QLineEdit, QPushButton, QFileDialog, QWidget, QMessageBox
from PyQt5.QtCore import QTimer, Qt, QSize
from PyQt5.QtGui import QPixmap, QIcon, QMovie

from database.taki_firebase_database import database, formatUsername, chatId, getMessages, sendMessage, markAsRead

def applyCircularAvatar(targetLabel, imagePath, avatarSize):
    originalPixmap = QtGui.QPixmap(imagePath).scaled(avatarSize, avatarSize, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
    circularPixmap = QtGui.QPixmap(avatarSize, avatarSize)
    circularPixmap.fill(Qt.transparent)

    painter = QtGui.QPainter(circularPixmap)
    painter.setRenderHint(QtGui.QPainter.Antialiasing)

    maskPath = QtGui.QPainterPath()
    maskPath.addEllipse(0, 0, avatarSize, avatarSize)
    painter.setClipPath(maskPath)
    painter.drawPixmap(0, 0, originalPixmap)
    painter.end()

    targetLabel.setPixmap(circularPixmap)

class ChatHeadItemWidget(QtWidgets.QWidget):
    def __init__(self, avatar_path, name):
        super().__init__()
        uic.loadUi("interface/taki_chat_head.ui", self)

        applyCircularAvatar(self.avatar, avatar_path, 64)
        self.name.setText(name)

class ChatItemWidget(QtWidgets.QWidget):
    def __init__(self, avatar_path, name, message, time, isSender, persona=True):
        super().__init__(),
        uic.loadUi("interface/taki_chat.ui", self)

        applyCircularAvatar(self.avatar, avatar_path, 48)
        self.name.setText(name)

        if not persona:
            self.message.setText(f"You: {message}" if isSender else message)
            self.time.setText(time)
        else:
            self.message.setText(message)
            self.time.hide()

class IncomingMessageWidget(QtWidgets.QWidget):
    def __init__(self, avatar_path, message):
        super().__init__()
        uic.loadUi("interface/taki_incoming_message.ui", self)

        applyCircularAvatar(self.avatar, avatar_path, 24)
        self.message.setText(message)

        QtCore.QTimer.singleShot(0, lambda: [
            self.message.document().setTextWidth(min(self.message.document().idealWidth(), 214)), # 214 is maximum width
            self.message.setFixedSize(
                int(self.message.document().size().width() + self.message.contentsMargins().left() + self.message.contentsMargins().right()),
                int(self.message.document().size().height() + self.message.contentsMargins().top() + self.message.contentsMargins().bottom())
            )
        ])

class OutgoingMessageWidget(QtWidgets.QWidget):
    def __init__(self, message):
        super().__init__()
        uic.loadUi("interface/taki_outgoing_message.ui", self)

        self.message.setText(message)

        QtCore.QTimer.singleShot(0, lambda: [
            self.message.document().setTextWidth(min(self.message.document().idealWidth(), 214)), # 214 is maximum width
            self.message.setFixedSize(
                int(self.message.document().size().width() + self.message.contentsMargins().left() + self.message.contentsMargins().right()),
                int(self.message.document().size().height() + self.message.contentsMargins().top() + self.message.contentsMargins().bottom())
            )
        ])

class EditProfileDialog(QDialog):
    def __init__(self, userData, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Edit Profile")
        self.setFixedSize(400, 250)

        self.defaultAvatarPath = "interface/images/avatar/default_avatar.png"
        self.avatarPath = (
            userData.get("avatar") if os.path.exists(userData.get("avatar") or "")
            else self.defaultAvatarPath
        )

        self.avatarLabel = QLabel()
        self.avatarLabel.setPixmap(QPixmap(self.avatarPath).scaled(80, 80, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        self.avatarLabel.setAlignment(Qt.AlignCenter)

        self.btnChangeAvatar = QPushButton("Change Avatar", clicked=self.chooseAvatar)
        self.btnResetAvatar = QPushButton("Set to Default", clicked=self.defaultAvatar)

        avatarLayout = QVBoxLayout()
        for widget in (self.avatarLabel, self.btnChangeAvatar, self.btnResetAvatar):
            avatarLayout.addWidget(widget)
        avatarLayout.setAlignment(Qt.AlignTop)

        self.usernameInput = QLineEdit(userData.get("username", ""))
        self.nameInput = QLineEdit(userData.get("name", ""))
        self.emailInput = QLineEdit(userData.get("email", ""))
        self.mobileInput = QLineEdit(str(userData.get("mobile") or ""))

        formLayout = QFormLayout()
        formLayout.addRow("Username:", self.usernameInput)
        formLayout.addRow("Name:", self.nameInput)
        formLayout.addRow("Email:", self.emailInput)
        formLayout.addRow("Mobile:", self.mobileInput)

        btnSave = QPushButton("Save", clicked=self.accept)
        btnCancel = QPushButton("Cancel", clicked=self.reject)

        buttonLayout = QHBoxLayout()
        buttonLayout.addWidget(btnCancel)
        buttonLayout.addWidget(btnSave)

        rightLayout = QVBoxLayout()
        rightLayout.addLayout(formLayout)
        rightLayout.addLayout(buttonLayout)

        mainLayout = QHBoxLayout()
        mainLayout.addLayout(avatarLayout)
        mainLayout.addLayout(rightLayout)
        self.setLayout(mainLayout)

    def chooseAvatar(self):
        filePath, _ = QFileDialog.getOpenFileName(self, "Choose Avatar", "", "Images (*.png *.jpg *.jpeg *.bmp)")
        if filePath:
            fileName = os.path.basename(filePath)
            targetPath = os.path.join("interface/images/avatar", fileName)
            if not os.path.exists(targetPath):
                shutil.copy(filePath, targetPath)
            self.avatarPath = targetPath
            self.avatarLabel.setPixmap(QPixmap(targetPath).scaled(80, 80, Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def defaultAvatar(self):
        self.avatarPath = self.defaultAvatarPath
        self.avatarLabel.setPixmap(QPixmap(self.avatarPath).scaled(80, 80, Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def getUpdatedData(self):
        return {
            "username": self.usernameInput.text().strip(),
            "name": self.nameInput.text().strip(),
            "email": self.emailInput.text().strip() or None,
            "mobile": self.mobileInput.text().strip() or None,
            "avatar": self.avatarPath
        }

class TakiSqliteDataBase:
    sqliteconnect = sqlite3.connect("database/taki_sqlite_database.db")
    cur = sqliteconnect.cursor()
    def exec_query(self, query, params=()):
        self.cur.execute(query, params)
        self.sqliteconnect.commit()

class MyApp(QMainWindow, TakiSqliteDataBase):
    def __init__(self):
        super().__init__()
        uic.loadUi("interface/taki.ui", self)
        
        self.setupLoadingOverlay()
        self.loadSplash()

    def setupLoadingOverlay(self):
        self.loadingOverlay = QWidget(self)
        self.loadingOverlay.setGeometry(self.rect())
        self.loadingOverlay.setStyleSheet("background-color: rgba(0, 0, 0, 80);")
        self.loadingOverlay.hide()

        self.loadingLabel = QLabel(self.loadingOverlay)
        self.loadingLabel.setFixedSize(64, 64)
        self.loadingLabel.setAlignment(Qt.AlignCenter)
        self.loadingLabel.setStyleSheet("background: transparent;")
        self.loadingLabel.move(
              (self.loadingOverlay.width() - 64) // 2,
              (self.loadingOverlay.height() - 64) // 2
        )

        self.loadingMovie = QMovie("interface/images/loading.gif")
        self.loadingMovie.setScaledSize(QSize(192, 192))
        self.loadingLabel.setMovie(self.loadingMovie)

    def showLoadingOverlay(self):
        self.loadingOverlay.setGeometry(self.rect())
        self.loadingOverlay.show()
        self.loadingLabel.show()
        self.loadingMovie.start()

    def hideLoadingOverlay(self):
        self.loadingMovie.stop()
        self.loadingLabel.hide()
        self.loadingOverlay.hide()

    def showAlertDialog(self, title, message):
        dialog = QMessageBox(self)
        dialog.setWindowTitle(title)
        dialog.setText(message)
        dialog.setStandardButtons(QMessageBox.Ok)
        dialog.exec_()

    # Splash
    def loadSplash(self):
        self.stackedWidget.setCurrentIndex(0)

        session = self.cur.execute("SELECT username FROM taki_session WHERE id = 1 AND is_logged_in = 1").fetchone()

        if session:
            self.signedInUser = session[0]
            QTimer.singleShot(3000, lambda: (
                self.stackedWidget.setCurrentIndex(4),
                self.setupHome()
            ))
        else:
            QTimer.singleShot(3000, lambda: (
                self.stackedWidget.setCurrentIndex(1),
                self.setupSignIn()
            ))

    # Sign-in
    def setupSignIn(self):
        self.siLineCredential.clear()
        self.siLinePassword.clear()

        def validateLoginCredentials():

            credentialInput = self.siLineCredential.text().strip() # Could be username, email, or mobile
            passwordInput = self.siLinePassword.text().strip()

            if not credentialInput or not passwordInput:
                self.showAlertDialog("Error", "Fields must be completed.")
                return

            self.showLoadingOverlay()

            def authenticate():
                try:
                    contacts = database.child("Taki").child("contacts").get()
                    matchedContact = None

                    if contacts.each():
                        for contactSnapshot in contacts.each():
                            contact = contactSnapshot.val()
                            if contact:
                                if (contact.get("username") == credentialInput or contact.get("email") == credentialInput or contact.get("mobile") == credentialInput):
                                    if contact.get("password") == passwordInput:
                                        matchedContact = contact
                                        break
                    if matchedContact:
                        self.signedInUser = matchedContact["username"]

                        self.cur.execute("""
                            INSERT OR REPLACE INTO taki_session (id, username, is_logged_in)
                            VALUES (1, ?, 1)
                        """, (self.signedInUser,))
                        self.sqliteconnect.commit()

                        self.stackedWidget.setCurrentIndex(4)
                        self.setupHome()
                    else:
                        self.showAlertDialog("Access Denied", "Invalid credential or password.")

                except Exception:
                    self.showAlertDialog("Error", "Unable to connect to Firebase.")
                finally:
                    self.hideLoadingOverlay()
                    
            QTimer.singleShot(3000, authenticate)

        try:
            self.btnSignIn.clicked.disconnect()
        except TypeError:
            pass
        self.btnSignIn.clicked.connect(validateLoginCredentials)

        self.siBtnCreateAccount.clicked.connect(
            lambda: (
                self.stackedWidget.setCurrentIndex(2),
                self.updateSignupStackHeight(),
                self.setupSignUp()
            )
        )

    # Sign-up
    def setupSignUp(self):
        self.suLineUsername.clear()
        self.suLabelErrorImage.hide()
        self.suLabelUsernameError.hide()
        self.suLinePassword.clear()
        self.suStackedWidget.setCurrentIndex(0)

        timer = QTimer(self, singleShot=True, interval=400)
        self.suLineUsername.textChanged.connect(timer.start)

        def validateUsername():
            username = self.suLineUsername.text().strip()
            self.suLabelUsernameError.hide()
            self.suLabelErrorImage.hide()
            
            if not username:
                self.suBtnNext.setEnabled(False)
                return
            
            try:
                if database.child("Taki").child("contacts").child(username).get().val() is not None: # Check if username exists
                    self.suLabelErrorImage.setIcon(QIcon("interface/images/icons/X_16.svg"))
                    self.suLabelUsernameError.setText(f"The username {username} is not available.")
                    self.suLabelUsernameError.show()
                    self.suBtnNext.setEnabled(False)
                else:
                    self.suLabelErrorImage.setIcon(QIcon("interface/images/icons/Check.svg"))
                    self.suBtnNext.setEnabled(True) 

                self.suLabelErrorImage.show()
                self.updateSignupStackHeight()
            except:
                self.showAlertDialog("Error", "Could not check this username.")

        timer.timeout.connect(validateUsername)

        self.suBtnBackState = "close" # Back
        self.suBtnBack.clicked.connect(lambda: (
            (
                self.stackedWidget.setCurrentIndex(1),
                self.setupSignIn()
            ) if self.suBtnBackState == "close" else (
                self.suStackedWidget.setCurrentIndex(0),
                self.suBtnBack.setIcon(QIcon("interface/images/icons/X.svg")),
                self.suLabelTitle.setText("Create username"),
                self.suLabelMessage.setText("Classic, yet yours to revise."),
                self.updateSignupStackHeight(),

                setattr(self, "suBtnBackState", "close"),
                setattr(self, "suBtnNextState", "next")
            )
        ))

        self.suBtnNextState = "next" # Next
        self.suBtnNext.clicked.connect(lambda: (
            (
                self.suStackedWidget.setCurrentIndex(1),
                self.suBtnBack.setIcon(QIcon("interface/images/icons/Arrow left.svg")),
                self.suLabelTitle.setText("Create a password"),
                self.suLabelMessage.setText("For Security, your password must be 6\n characters or more."),
                self.suLinePassword.textChanged.connect(
                    lambda text: self.suBtnNext.setEnabled(bool(text.strip()))
                ),
                self.suCheckShowPassword.stateChanged.connect(
                    lambda state: self.suLinePassword.setEchoMode(
                        QtWidgets.QLineEdit.Normal if state == Qt.Checked else QtWidgets.QLineEdit.Password
                    )
                ),
                self.updateSignupStackHeight(),

                setattr(self, "suBtnBackState", "back"),
                setattr(self, "suBtnNextState", "complete")
            ) if self.suBtnNextState == "next" else (
                self.stackedWidget.setCurrentIndex(3),
                self.setupWelcome()
            ) if self.suLinePassword.text().strip() else None
        ))

    def updateSignupStackHeight(self):
        QTimer.singleShot(0, lambda: self.suStackedWidget.setFixedHeight(
            self.suStackedWidget.currentWidget().sizeHint().height()
        ))

    # Welcome
    def setupWelcome(self):
        self.wLabelTitle.setText(f"Welcome to\n Taki, {self.suLineUsername.text().strip()}")
        self.wLabelMessage.setText("Chika all day, Taki all the way.")
        
        try:
            self.btnCompleteSignUp.clicked.disconnect()
        except TypeError:
            pass
        self.btnCompleteSignUp.clicked.connect(lambda: (
            self.showLoadingOverlay(),
            QTimer.singleShot(3000, lambda: (
                registerContact(),
                setattr(self, "signedInUser", self.suLineUsername.text().strip()),
                self.cur.execute(
                    """INSERT OR REPLACE INTO taki_session (id, username, is_logged_in) VALUES (1, ?, 1)""",
                    (self.signedInUser,)
                ),
                self.sqliteconnect.commit(),
                self.stackedWidget.setCurrentIndex(4),
                self.setupHome(),
                self.hideLoadingOverlay()
            ))
        ))

        def registerContact():
            username = self.suLineUsername.text().strip()
            password = self.suLinePassword.text().strip()

            try:
                database.child("Taki").child("contacts").child(username).set({
                    "name": "",
                    "username": username,
                    "password": password,
                    "email": "",
                    "mobile": "",
                    "avatar": "",
                    "joined" : "",
                    "status" : ""
                })  
            except:
                self.showAlertDialog("Error", "Could not create this contact.")

    def setupHome(self):
        QTimer.singleShot(100, self.recentChats)  # Initial load

        self.hBtnProfile.clicked.connect(lambda: (
            self.stackedWidget.setCurrentIndex(7),
            self.setupProfile()
        ))

        self.hBtnNewChat.clicked.connect(lambda: (
            self.stackedWidget.setCurrentIndex(5),
            self.setupStartChat()
        ))

    def recentChats(self):
        if hasattr(self, "chatRefreshTimer"):
            try:
                self.chatRefreshTimer.stop()
                self.chatRefreshTimer.timeout.disconnect()
            except Exception:
                pass
        else:
            self.chatRefreshTimer = QTimer(self)
            
        QTimer.singleShot(100, lambda: (
            self.chatRefreshTimer.timeout.connect(self.recentChats),
            self.chatRefreshTimer.start(5000)
        ))
        
        chatHeadList = self.findChild(QtWidgets.QListWidget, "hListChatHead")
        chatList = self.findChild(QtWidgets.QListWidget, "hListChat")

        chatHeadList.blockSignals(True)
        chatList.blockSignals(True)

        chatHeadList.clear()
        chatList.clear()

        chatHeadList.setFlow(QtWidgets.QListView.LeftToRight)
        chatHeadList.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        chatHeadList.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        chatList.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        chatList.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        contacts = database.child("Taki").child("contacts").get()
        if not contacts.each():
            chatHeadList.blockSignals(False)
            chatList.blockSignals(False)
            return

        chats = {}
        for contact in contacts.each():
            uid = contact.key()
            if formatUsername(self.signedInUser) == uid:
                continue

            messages = getMessages(self.signedInUser, uid)
            if not messages:
                messages = getMessages(uid, self.signedInUser)
            if not messages:
                continue

            chats[uid] = messages[-1]  # last message

        for uid, recentMessage in sorted(chats.items(), key=lambda item: item[1]["timestamp"], reverse=True):
            sender = recentMessage["sender"]
            message = recentMessage["message"]
            timestamp = recentMessage["timestamp"]
            isSender = sender == self.signedInUser
            isRead = recentMessage.get("read", False)

            try:
                dt = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S")
            except:
                dt = datetime.now()
            time = dt.strftime("%I:%M %p").lstrip("0")

            contact = database.child("Taki").child("contacts").child(uid).get().val()
            avatar = contact.get("avatar") if contact.get("avatar") and os.path.exists(contact.get("avatar")) else "interface/images/avatar/default_avatar.png"
            name = contact.get("name", uid)

            chatHeadItem = ChatHeadItemWidget(avatar, name.split()[0])
            headItem = QListWidgetItem()
            headItem.setSizeHint(chatHeadItem.sizeHint())
            chatHeadList.addItem(headItem)
            chatHeadList.setItemWidget(headItem, chatHeadItem)

            chatItem = ChatItemWidget(avatar, name, message, time, isSender, False)
            chatItem.message.setStyleSheet(
                f'color: {"black" if not isRead else "gray"}; font: 14px "Segoe UI Semibold";')
            listItem = QListWidgetItem()
            listItem.setSizeHint(chatItem.sizeHint())
            chatList.addItem(listItem)
            chatList.setItemWidget(listItem, chatItem)

            def openChat(username=uid, name=name, avatar=avatar):
                self.openChatConversation(avatar, name, username, "Online")

            chatHeadItem.mousePressEvent = lambda e, func=openChat: func()
            chatItem.mousePressEvent = lambda e, func=openChat: func()

        chatHeadList.blockSignals(False)
        chatList.blockSignals(False)

    # Start chat
    def setupStartChat(self):
        try:
            self.chatRefreshTimer.stop()
            self.chatRefreshTimer.timeout.disconnect()
        except Exception:
            pass

        self.scLineCredential.clear()
        chatList = self.findChild(QtWidgets.QListWidget, "scListPersona")
        chatList.clear()

        self.scBtnBack.clicked.connect(lambda: (
            self.stackedWidget.setCurrentIndex(4),
            QtCore.QTimer.singleShot(100, self.recentChats)
        ))

        chatList.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        chatList.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self.searchTimer = QtCore.QTimer(self)
        self.searchTimer.setSingleShot(True)
        self.searchTimer.setInterval(400)

        def loadUserResults():
            credential = self.scLineCredential.text().strip()
            if not credential:
                chatList.clear()
                return

            try:
                contacts = database.child("Taki").child("contacts").get()
                if not contacts.each():
                    chatList.clear()
                    return

                matches = []
                for contact in contacts.each():
                    data = contact.val()
                    username = data.get("username", "")
                    email = data.get("email", "")
                    mobile = data.get("mobile", "")
                    name = data.get("name", "")
                    avatar = data.get("avatar", "")

                    if username.startswith(credential) or email.startswith(credential) or mobile.startswith(credential):
                        avatar = avatar if avatar and os.path.exists(avatar) else "interface/images/avatar/default_avatar.png"

                        item = QListWidgetItem()
                        widget = ChatItemWidget(avatar, name, username, "", True)
                        item.setSizeHint(widget.sizeHint())
                        item.setData(Qt.UserRole, {
                            "avatar": avatar,
                            "name": name,
                            "username": username,
                            "status": "Online"
                        })
                        matches.append((item, widget))

                chatList.clear()
                for item, widget in matches:
                    chatList.addItem(item)
                    chatList.setItemWidget(item, widget)

            except Exception as e:
                print("Error loading contacts:", e)

        self.scLineCredential.textChanged.connect(lambda: self.searchTimer.start())
        self.searchTimer.timeout.connect(loadUserResults)

        chatList.itemClicked.connect(lambda item: self.openChatConversation(
            item.data(Qt.UserRole)["avatar"],
            item.data(Qt.UserRole)["name"],
            item.data(Qt.UserRole)["username"],
            item.data(Qt.UserRole)["status"]
        ))

    # Message
    def openChatConversation(self, avatar, name, username, status):
        try:
            self.chatRefreshTimer.stop()
            self.chatRefreshTimer.timeout.disconnect()
        except Exception:
            pass

        applyCircularAvatar(self.mLabelAvatar, avatar, 32)
        self.mLabelName.setText(name)
        self.mLabelStatus.setText(status)

        self.currentChatUsername = username
        self.lastLoadedTimestamp = None
        self.loadedMessageIds = set()
        self.mChatList.clear()

        self.stackedWidget.setCurrentIndex(6)

        def loadMessages(initial=False):
            messages = getMessages(self.signedInUser, self.currentChatUsername)
            messages = sorted(messages, key=lambda m: m.get("timestamp", ""))

            newMessages = []

            for message in messages:
                timestamp = message.get("timestamp", "")
                messageId = message.get("id", timestamp + message.get("message", ""))  # fallback unique

                if messageId in self.loadedMessageIds:
                    continue
                if self.lastLoadedTimestamp and timestamp <= self.lastLoadedTimestamp:
                    continue

                newMessages.append(message)
                self.loadedMessageIds.add(messageId)
                self.lastLoadedTimestamp = timestamp

            if not newMessages:
                return  # Skip redraw

            for message in newMessages:
                if message.get("sender") == self.signedInUser:
                    self.addOutgoingMessage(message.get("message"))
                elif message.get("sender") == self.currentChatUsername:
                    self.addIncomingMessage(avatar, message.get("message"))

            if initial:
                QtCore.QTimer.singleShot(0, self.mChatList.scrollToBottom)

            markAsRead(self.signedInUser, self.currentChatUsername)

        QtCore.QTimer.singleShot(100, lambda: loadMessages(initial=True))

        try:
            self.messageRefreshTimer.timeout.disconnect()
        except Exception:
            pass

        self.messageRefreshTimer = QtCore.QTimer(self)
        self.messageRefreshTimer.timeout.connect(loadMessages)
        self.messageRefreshTimer.start(2000)

        self.mBtnBack.clicked.connect(lambda: (
            self.messageRefreshTimer.stop(),
            self.stackedWidget.setCurrentIndex(4),
            QtCore.QTimer.singleShot(100, self.recentChats)
        ))

        self.mBtnSendMessage.clicked.connect(self.sendMessage)

    def addIncomingMessage(self, avatar, message):
        widget = IncomingMessageWidget(avatar, message)
        item = QListWidgetItem()
        self.mChatList.addItem(item)
        self.mChatList.setItemWidget(item, widget)

        def updateSize():
            item.setSizeHint(widget.sizeHint())
            self.mChatList.scrollToBottom()

        QtCore.QTimer.singleShot(0, updateSize)
        widget.mousePressEvent = lambda e: None

    def addOutgoingMessage(self, message):
        widget = OutgoingMessageWidget(message)
        item = QListWidgetItem()
        self.mChatList.addItem(item)
        self.mChatList.setItemWidget(item, widget)

        def updateSize():
            item.setSizeHint(widget.sizeHint())
            self.mChatList.scrollToBottom()

        QtCore.QTimer.singleShot(0, updateSize)
        widget.mousePressEvent = lambda e: None

    def sendMessage(self):
        text = self.mInputMessage.toPlainText().strip()
        if text:
            self.mInputMessage.clear()
            sendMessage(self.signedInUser, self.currentChatUsername, text)

    # Profile
    def setupProfile(self):
        try:
            self.chatRefreshTimer.stop()
            self.chatRefreshTimer.timeout.disconnect()
        except Exception:
            pass

        def loadUserProfile(signedInUser):
            try:
                contact = database.child("Taki").child("contacts").child(signedInUser).get().val()

                if contact:
                    avatar = contact.get("avatar")
                    name = contact.get("name")
                    username = contact.get("username")
                    status = contact.get("status")
                    email = contact.get("email")
                    mobile = contact.get("mobile")

                    applyCircularAvatar(self.pLabelAvatar, avatar if avatar and os.path.exists(avatar) else "interface/images/avatar/default_avatar.png", 80)
                    self.pLabelName.setText(name)
                    self.pLabelUsername.setText(username)
                    self.pLabelStatus.setText(status or "Active"),
                    self.pLabelEmailMessage.setText(email)
                    self.pLabelMobileMessage.setText(f"+63{mobile or ''}")
                else:
                    self.showAlertDialog("Error", "User data not found.")
            except Exception as e:
                self.showAlertDialog("Error", f"Failed to load profile:\n{str(e)}")

        QTimer.singleShot(100, lambda: loadUserProfile(self.signedInUser))

        self.pBtnBack.clicked.connect(lambda: (
            self.stackedWidget.setCurrentIndex(4),
            QtCore.QTimer.singleShot(100, self.recentChats)
        ))

        try:
            self.pBtnEdit.clicked.disconnect()
        except TypeError:
            pass
        self.pBtnEdit.clicked.connect(self.openEditProfileDialog)

        self.btnSignOut.clicked.connect(lambda: (
            self.showLoadingOverlay(),
            QTimer.singleShot(3000, lambda: (
                self.cur.execute("DELETE FROM taki_session WHERE id = 1"),
                self.sqliteconnect.commit(),
                self.hideLoadingOverlay(),
                self.stackedWidget.setCurrentIndex(1),
                self.setupSignIn()
            ))
        ))

    def openEditProfileDialog(self):
        try:
            contact = database.child("Taki").child("contacts").child(self.signedInUser).get().val()
            if not contact:
                return self.showAlertDialog("Error", "User not found.")
            
            fields = ["username", "name", "password", "email", "mobile", "avatar", "joined", "status"]
            currentData = {field: contact.get(field, "") for field in fields}
            originalUsername = currentData["username"]

            while True:
                dialog = EditProfileDialog(currentData.copy(), self)
                if not dialog.exec_():
                    break  # Cancelled

                updatedData = dialog.getUpdatedData()

                for field in fields:
                    if field not in updatedData:
                        updatedData[field] = contact.get(field, "")
                    elif updatedData[field] is None:
                        updatedData[field] = ""

                contacts = database.child("Taki").child("contacts").get().val()
                conflict = False
                for field in ("username", "email", "mobile"):
                    value = updatedData[field]
                    if value:
                        for key, user in (contacts or {}).items():
                            if user.get(field) == value and user.get("username") != originalUsername:
                                self.showAlertDialog("Error", f"{field.capitalize()} is already in use.")
                                currentData.update(updatedData)
                                conflict = True
                                break
                    if conflict:
                        break

                if not conflict:
                    if updatedData["username"] != originalUsername:
                        chatRoot = database.child("Taki").child("chats").get().val() or {}

                        for chatKey in chatRoot.keys():
                            if originalUsername in chatKey:
                                chatData = chatRoot[chatKey]

                                for itemKey, itemValue in chatData.items():
                                    if isinstance(itemValue, dict) and itemValue.get("sender") == originalUsername:
                                        itemValue["sender"] = updatedData["username"]
                                        chatData[itemKey] = itemValue  # update message in chatData

                                database.child("Taki").child("chats").child(chatKey.replace(originalUsername, updatedData["username"])).set(chatData)
                                database.child("Taki").child("chats").child(chatKey).remove()

                        database.child("Taki").child("contacts").child(updatedData["username"]).set({
                            **contact,
                            **updatedData
                        })
                        database.child("Taki").child("contacts").child(originalUsername).remove()
                        self.signedInUser = updatedData["username"]
                        self.cur.execute(
                            """INSERT OR REPLACE INTO taki_session (id, username, is_logged_in) VALUES (1, ?, 1)""", 
                            (self.signedInUser,)
                        )
                        self.sqliteconnect.commit()
                    else:
                        database.child("Taki").child("contacts").child(originalUsername).update(updatedData)

                    self.showLoadingOverlay()
                    QTimer.singleShot(3000, lambda: (
                        applyCircularAvatar(
                            self.pLabelAvatar,
                            updatedData["avatar"] if updatedData["avatar"] and os.path.exists(updatedData["avatar"]) else "interface/images/avatar/default_avatar.png",
                            80
                        ),
                        self.pLabelName.setText(updatedData["name"]),
                        self.pLabelUsername.setText(updatedData["username"]),
                        self.pLabelStatus.setText(updatedData["status"]),
                        self.pLabelEmailMessage.setText(updatedData["email"]),
                        self.pLabelMobileMessage.setText(f"+63{updatedData["mobile"] or ''}"),
                        self.hideLoadingOverlay()
                    ))
                    break
        except Exception as e:
            self.showAlertDialog("Error", f"Failed to open edit profile:\n{str(e)}")

app = QApplication(sys.argv)
window = MyApp()
window.show()
sys.exit(app.exec_())

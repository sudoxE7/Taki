from PyQt5 import QtWidgets, uic, QtGui, QtCore
from PyQt5.QtWidgets import QApplication, QMainWindow, QListWidgetItem
from PyQt5.QtCore import QTimer, Qt
from PyQt5.QtGui import QIcon
import sys

def setRoundedAvatar(label, image_path, size):
    pixmap = QtGui.QPixmap(image_path).scaled(size, size, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
    rounded = QtGui.QPixmap(size, size)
    rounded.fill(Qt.transparent)

    painter = QtGui.QPainter(rounded)
    painter.setRenderHint(QtGui.QPainter.Antialiasing)
    path = QtGui.QPainterPath()
    path.addEllipse(0, 0, size, size)
    painter.setClipPath(path)
    painter.drawPixmap(0, 0, pixmap)
    painter.end()

    label.setPixmap(rounded)

class ChatHeadItemWidget(QtWidgets.QWidget):
    def __init__(self, avatar_path, name):
        super().__init__()
        uic.loadUi("chat_head.ui", self)
        setRoundedAvatar(self.avatar_2, avatar_path, 64)
        self.name_2.setText(name)

class ChatItemWidget(QtWidgets.QWidget):
    def __init__(self, avatar_path, name, message, time):
        super().__init__()
        uic.loadUi("chat.ui", self)
        setRoundedAvatar(self.avatarLabel, avatar_path, 48)
        self.nameLabel.setText(name)
        self.messageLabel.setText(message)
        self.timeLabel.setText(time)

class IncomingMessageWidget(QtWidgets.QWidget):
    def __init__(self, avatar_path, message):
        super().__init__()
        uic.loadUi("incoming_message.ui", self)
        setRoundedAvatar(self.avatarLabel, avatar_path, 24)
        self.messageLabel.setText(message)

class OutgoingMessageWidget(QtWidgets.QWidget):
    def __init__(self, message):
        super().__init__()
        uic.loadUi("outgoing_message.ui", self)
        self.messageLabel.setText(message)

class MyApp(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("taki.ui", self)

        self.setupSplash()
        self.setupSignIn()
        self.setupSignUp()
        self.setupWelcome()
        self.setupHome()
        self.setupProfile()
        self.setupMessage()

    # Splash
    def setupSplash(self):
        self.stackedWidget.setCurrentIndex(0)
        QTimer.singleShot(3000, lambda: self.stackedWidget.setCurrentIndex(1))

    # Sign-in
    def setupSignIn(self):
        self.siBtnCreateAccount.clicked.connect(
            lambda: (self.stackedWidget.setCurrentIndex(2), self.updateSignupStackHeight())
        )

        self.btnSignIn.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(4))

    # Sign-up
    def setupSignUp(self):
        self.suBtnBack.setIcon(QIcon("images/X.svg"))
        self.suBtnBackState = "close"
        self.suBtnBack.clicked.connect(self.handleSignupBack)

        self.suBtnNextState = "next"
        self.suBtnNext.clicked.connect(self.handleSignupNext)

        self.suLabelUsernameError.hide()
        self.suLabelErrorImage.hide()

    def updateSignupStackHeight(self):
        QTimer.singleShot(0, lambda: self.suStackedWidget.setFixedHeight(
            self.suStackedWidget.currentWidget().sizeHint().height()
        ))

    def handleSignupBack(self):
        if self.suBtnBackState == "close":
            self.stackedWidget.setCurrentIndex(1)
        else:
            self.suStackedWidget.setCurrentIndex(0)
            self.suBtnBack.setIcon(QIcon("images/X.svg"))
            self.suBtnBackState = "close"
            self.suBtnNextState = "next"
            self.suLabelTitle.setText("Create username")
            self.suLabelMessage.setText("Classic, yet yours to revise.")
            self.updateSignupStackHeight()

    def handleSignupNext(self):
        if self.suBtnNextState == "next":
            self.suBtnBack.setIcon(QIcon("images/Arrow left.svg"))
            self.suBtnBackState = "back"
            self.suBtnNextState = "complete"
            self.suLabelTitle.setText("Create a password")
            self.suLabelMessage.setText("For Security, your password must be 6\n characters or more.")
            self.suStackedWidget.setCurrentIndex(1)
            self.updateSignupStackHeight()
        else:
            self.stackedWidget.setCurrentIndex(3)

    # Welcome
    def setupWelcome(self):
        self.btnCompleteSignUp.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(4))

    # Home
    def setupHome(self):
        self.setupChatHeads()
        self.setupChatList()

        self.hBtnProfile.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(6))

    def setupChatHeads(self):
        chat_heads = [
            ("images\Angeles.jpg", "Arwin"),
            ("images\lunggakit.png", "Johnides"),
            ("images\gamboa.jpg", "Joshua"),
            ("images\capiral.jpg", "Tjrey"),
            ("images\Rie.jpg", "Andrie"),
        ]
        chatHeadList = self.findChild(QtWidgets.QListWidget, "hListChatHead")
        chatHeadList.setFlow(QtWidgets.QListView.LeftToRight)
        chatHeadList.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        chatHeadList.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        for avatar, name in chat_heads:
            widget = ChatHeadItemWidget(avatar, name)
            item = QListWidgetItem()
            item.setSizeHint(widget.sizeHint())
            chatHeadList.addItem(item)
            chatHeadList.setItemWidget(item, widget)
        
        chatHeadList.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(5))

    def setupChatList(self):
        chats = [
            ("images\Angeles.jpg", "Arwin Angeles", "Taena", "2:11"),
            ("images\lunggakit.png", "Johnide Lunggakit", "Oy pre", "1:15 PM"),
            ("images\gamboa.jpg", "Joshua Gamboa", "Gege", "1:04"),
            ("images\capiral.jpg", "Tjrey Capiral", "Bakal ako.", "3:45"),
            ("images\Rie.jpg", "Andrie De Ocampo", "Classic.", "11:14"),
        ]
        chatList = self.findChild(QtWidgets.QListWidget, "hListChat")
        chatList.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        chatList.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        for avatar, name, message, time in chats:
            widget = ChatItemWidget(avatar, name, message, time)
            item = QListWidgetItem()
            item.setSizeHint(widget.sizeHint())
            chatList.addItem(item)
            chatList.setItemWidget(item, widget)

        chatList.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(5))

    # Profile
    def setupProfile(self):
        self.pBtnBack.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(4))
        self.btnSignOut.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(1))
        setRoundedAvatar(self.pLabelAvatar, "images\lunggakit.png", 80)

    # Message
    def setupMessage(self):
        self.mBtnBack.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(4))
        setRoundedAvatar(self.mLabelAvatar, "images/rie.jpg", 32)
        self.mBtnSendMessage.clicked.connect(self.sendMessage)
        self.populateMessages()

    def populateMessages(self):
        self.addIncomingMessage("images/rie.jpg", "Pre")
        self.addOutgoingMessage("Oh")
        self.addIncomingMessage("images/rie.jpg", "Tanginamo hahah")

    def addIncomingMessage(self, avatar, message):
        widget = IncomingMessageWidget(avatar, message)
        item = QListWidgetItem()
        item.setSizeHint(widget.sizeHint())
        self.mChatList.addItem(item)
        self.mChatList.setItemWidget(item, widget)

    def addOutgoingMessage(self, message):
        widget = OutgoingMessageWidget(message)
        item = QListWidgetItem()
        item.setSizeHint(widget.sizeHint())
        self.mChatList.addItem(item)
        self.mChatList.setItemWidget(item, widget)

    def sendMessage(self):
        text = self.mInputMessage.toPlainText().strip()
        if text:
            self.addOutgoingMessage(text)
            self.mInputMessage.clear()

app = QApplication(sys.argv)
window = MyApp()
window.show()
sys.exit(app.exec_())
